# Final Capstone Project

Provision infra with Terraform and deploy app with Kubernetes