# Week 1 – Docker Basics

## Goals
- Understand Docker concepts
- Run containers

## Key Commands
```bash
docker run hello-world
docker ps
docker build -t myapp .
```