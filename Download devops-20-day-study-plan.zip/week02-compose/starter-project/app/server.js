const express = require('express'); const redis = require('redis');
const app = express();
const client = redis.createClient({ url: 'redis://redis:6379' });
client.on('error', err => console.log('Redis Client Error', err));
client.connect();
app.get('/', async (req, res) => {
  let visits = await client.get('visits') || 0;
  visits++;
  await client.set('visits', visits);
  res.send(`Number of visits is ${visits}`);
});
app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});