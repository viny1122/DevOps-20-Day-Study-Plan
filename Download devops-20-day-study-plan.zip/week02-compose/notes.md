# Week 2 – Docker Compose

## Goals
- Run multi-container apps

## Commands
```bash
docker compose up -d
docker compose ps
docker compose down
```