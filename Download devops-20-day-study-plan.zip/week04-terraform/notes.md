# Week 4 – Terraform

## Goals
- Provision AWS with IaC

## Commands
```bash
terraform init
terraform apply -auto-approve
```